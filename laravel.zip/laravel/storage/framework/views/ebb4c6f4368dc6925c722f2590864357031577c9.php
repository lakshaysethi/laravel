<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <meta name="description" content="">
	    <meta name="author" content="">

	    <title>Plant Me</title>
	</head>
	<body id="home" style="font-family: 'Baloo Da', Arial, sans-serif;">
		<!--<?php echo $__env->make('info.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>-->

		<?php echo $__env->yieldContent('content'); ?>

		<!--<?php echo $__env->make('info.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>-->
		
		
	</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/layouts/main.blade.php ENDPATH**/ ?>